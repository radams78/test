import * as Express from "express";
import { taskRouter } from "./router/task.router";

export const app : Express.Express = Express();

app.use(Express.json());
app.use("/task", taskRouter());