import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

class Bookmark extends React.Component<{ title: string, link: string, description: string }> {
  private buttonText : string = "Click me";

  render() {
    return <li>
      <h2>{this.props.title}</h2>
      <a href={this.props.link}>this.props.description</a>
      <button onClick={() => {
        this.buttonText = "I was clicked";
        this.setState({});
      }}>{this.buttonText}</button>
    </li>;
  }
}

const rootElement =
  <div>
    <h1>Bookmarks</h1>
    <ul>
      <Bookmark title={"Etherient" + (2 + 2)} link="https://www.etherient.com" description="Home page of Etherient" />
      <Bookmark title="Chalmers" link="https://www.chalmers.se" description="Home page of Chalmers" />
    </ul>
  </div>

ReactDOM.render(rootElement,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
